import os
import sys
import pandas as pd
import numpy as np
import gseapy as gp
from scipy.spatial.distance import pdist, squareform
from sklearn.preprocessing import normalize
import scanpy as sc
from scipy.stats import norm

def load_matrix_for_GSE(path):
    if not os.path.exists(path):
        raise FileNotFoundError(f"The file {path} does not exist.")
    expr_matrix = pd.read_csv(path, index_col=0)
    print(f"Loaded gene expression matrix with shape: {expr_matrix.shape}")
    return expr_matrix

def load_all_pathways(path):
    gmt_files = [f for f in os.listdir(path) if f.endswith('.gmt')]
    gsets = {}
    for gmt_file in gmt_files:
        gsets[gmt_file] = gp.parser.read_gmt(os.path.join(path, gmt_file))
    return gsets

def clean_sets(gSet, min_size=10, max_size=500):
    filtered_gset = {k: v for k, v in gSet.items() if min_size <= len(v) <= max_size}
    return filtered_gset

def pathway_scoring(gSet, mat_gene):
    auc_mtx = np.zeros((mat_gene.shape[0], len(gSet)))  # Adjusted for cells as rows

    for j, (pathway_name, pathway_genes) in enumerate(gSet.items()):
        genes_in_pathway = list(set(pathway_genes).intersection(set(mat_gene.columns)))
        if len(genes_in_pathway) > 0:
            pathway_matrix = mat_gene[genes_in_pathway]
            scores = pathway_matrix.mean(axis=1)
            auc_mtx[:, j] = scores

    auc_mtx = auc_mtx[:, np.sum(auc_mtx, axis=0) > 0]  # Remove zero columns
    print(f"Pathway score matrix shape: {auc_mtx.shape}")
    return auc_mtx

def standard_normalization(matrix):
    return normalize(matrix, norm='l2', axis=1)

def affinity_matrix(diff, K=20, sigma=0.5):
    """
    Constructs similarity networks based on the provided distance matrix.
    
    Parameters:
    - diff: A distance matrix (NxN), where N is the number of data points.
    - K: The number of nearest neighbors to consider for calculating local density (default is 20).
    - sigma: A scaling factor for the Gaussian kernel (default is 0.5).
    
    Returns:
    - W: A similarity (affinity) matrix (NxN).
    """
    N = diff.shape[0]

    # Symmetrize the distance matrix
    diff = (diff + diff.T) / 2
    
    # Set the diagonal to 0
    np.fill_diagonal(diff, 0)
    
    # Sort each column of the distance matrix
    sorted_columns = np.sort(diff, axis=0)
    
    # Calculate the mean of the first K+1 sorted distances for each row
    means = np.mean(sorted_columns[:K+1, :], axis=0) + np.finfo(np.float32).eps
    
    # Calculate sigma (Sig) using the means
    avg = lambda x, y: (x + y) / 2
    Sig = np.add.outer(means, means) * 2 / 3 + diff / 3 + np.finfo(np.float32).eps
    Sig[Sig <= np.finfo(np.float32).eps] = np.finfo(np.float32).eps
    
    # Calculate the density (similarity) using a normal distribution
    densities = norm.pdf(diff, 0, sigma * Sig)
    
    # Symmetrize the density matrix
    W = (densities + densities.T) / 2
    
    return W

def get_cell_similarity_matrix(mat_path, K=20, mu=0.5):
    print(f"Matrix for similarity calculation shape: {mat_path.shape}")
    mat_path = standard_normalization(mat_path)
    distance = pdist(mat_path, metric='euclidean')
    distance_matrix = squareform(distance)
    similarity_matrix = affinity_matrix(distance_matrix, K=K, sigma=mu)

    # Ensure similarity_matrix is square
    print(f"Similarity matrix shape: {similarity_matrix.shape}")
    if similarity_matrix.shape[0] != similarity_matrix.shape[1]:
        raise ValueError("The similarity matrix is not square!")
    
    return similarity_matrix

def get_mat_path(mat_gene, gsets):
    mat_paths = {}
    for name, gSet in gsets.items():
        gSet = clean_sets(gSet)
        mat_path = pathway_scoring(gSet, mat_gene)
        mat_paths[name] = mat_path
    return mat_paths

def mat_gene_reduction(mat_gene):
    adata = sc.AnnData(mat_gene)
    sc.pp.normalize_total(adata)
    sc.pp.log1p(adata)
    sc.pp.highly_variable_genes(adata, n_top_genes=min(2000, mat_gene.shape[1]))
    sc.pp.scale(adata)
    sc.tl.pca(adata, n_comps=min(30, mat_gene.shape[0]))
    pca_result = adata.obsm['X_pca']
    return pca_result

def get_cell_similarity_matrix_by_genes(mat_gene, K=20, mu=0.5):
    mat_gene_reduced = mat_gene_reduction(mat_gene)
    mat_gene_reduced = standard_normalization(mat_gene_reduced)
    gene_distances = pdist(mat_gene_reduced, metric='euclidean')
    distance_matrix = squareform(gene_distances)
    similarity_matrix = affinity_matrix(distance_matrix, K=K, sigma=mu)

    # Ensure similarity_matrix is square
    print(f"Gene-based similarity matrix shape: {similarity_matrix.shape}")
    if similarity_matrix.shape[0] != similarity_matrix.shape[1]:
        raise ValueError("The similarity matrix is not square!")

    return similarity_matrix

def main(data_path, pathway_path, data_num=1, view_num=4):
    gsets = load_all_pathways(pathway_path)

    for i in range(1, data_num + 1):
        mat_name = f'data_{i}.csv'
        mat_path = os.path.join(data_path, mat_name)
        mat_gene = load_matrix_for_GSE(mat_path)

        for j, (name, mat_path) in enumerate(get_mat_path(mat_gene, gsets).items(), 1):
            save_path_W = os.path.join(data_path, f'sm_{i}_{j}.csv')
            save_path_mat_path = os.path.join(data_path, f'mat_path_{i}_{j}.csv')

            W = get_cell_similarity_matrix(mat_path)

            print(f"Save the similarity matrix for pathway {name}")
            # Ensure the index is included when saving to CSV
            W_df = pd.DataFrame(W, index=mat_gene.index, columns=mat_gene.index)
            W_df.to_csv(save_path_W, index=True)

        # Generate gene-based similarity matrix
        mat_sm_gene = get_cell_similarity_matrix_by_genes(mat_gene)
        print(f"Save the gene-based similarity matrix")
        save_path_gene = os.path.join(data_path, f'sm_{i}_{view_num + 1}_.csv')
        mat_sm_gene_df = pd.DataFrame(mat_sm_gene, index=mat_gene.index, columns=mat_gene.index)
        mat_sm_gene_df.to_csv(save_path_gene, index=True)

if __name__ == '__main__':
    pathway_path = "C:\\Users\\fotin\\scPML\\demo\\pathway_data\\human"
    args = sys.argv[1:]
    base_path = args[0]

    data_path_ref = os.path.join(base_path, 'raw_data', 'ref')
    main(data_path_ref, pathway_path, data_num=1, view_num=4)

    data_path_query = os.path.join(base_path, 'raw_data', 'query')
    main(data_path_query, pathway_path, data_num=1, view_num=4)
