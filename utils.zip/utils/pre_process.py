import os
import sys
import pandas as pd
import numpy as np
from scipy.stats import f_oneway

def read_data(path):
    return pd.read_csv(path, index_col=0)

def read_label(path):
    return pd.read_csv(path)

def select_feature(data, label, nf=2000):
    new_label = label.iloc[:, 0].values
    f_values, p_values = [], []

    for gene in data.columns:  # Adjust for genes as columns
        if data[gene].nunique() > 1:  # Check if gene has more than one unique value
            groups = [data[gene][new_label == cls] for cls in np.unique(new_label)]
            f_val, p_val = f_oneway(*groups)
            f_values.append(f_val)
            p_values.append(p_val)
        else:
            f_values.append(0)
            p_values.append(1)

    fdr = np.argsort(p_values)[:nf]
    selected_genes = data.columns[fdr]
    return selected_genes

def normalize_data(data):
    row_sum = data.sum(axis=1)
    mean_t = row_sum.mean()

    row_sum[row_sum == 0] = 1
    data = data.div(row_sum, axis=0) * mean_t
    return data

def main(ref_data_path, query_data_path, ref_label_path, ref_save_path, query_save_path):
    ref_data = read_data(ref_data_path)
    ref_label = read_label(ref_label_path)
    query_data = read_data(query_data_path)

    #print("Dimensions of reference data:", ref_data.shape)
    #print("Dimensions of reference label:", ref_label.shape)
    #print("Head of reference data:\n", ref_data.head())
    #print("Head of reference label:\n", ref_label.head())

    # Check if the rows in ref_data match the number of rows in ref_label
    if ref_data.shape[0] != ref_label.shape[0]:
        print(f"Error: Mismatch in dimensions - {ref_label.shape[0]} labels and {ref_data.shape[0]} samples")
        return

    sel_features = select_feature(ref_data, ref_label)
    sel_ref_data = ref_data[sel_features]
    sel_query_data = query_data[sel_features]

    norm_ref_data = normalize_data(sel_ref_data)
    norm_query_data = normalize_data(sel_query_data)

    norm_ref_data.to_csv(ref_save_path)
    norm_query_data.to_csv(query_save_path)

if __name__ == '__main__':
    base_path = sys.argv[1]
    ref_data_path = os.path.join(base_path, 'raw_data', 'ref', 'data_1.csv')
    query_data_path = os.path.join(base_path, 'raw_data', 'query', 'data_1.csv')
    ref_label_path = os.path.join(base_path, 'raw_data', 'ref', 'label_1.csv')

    ref_save_path = os.path.join(base_path, 'data', 'ref', 'data_1.csv')
    query_save_path = os.path.join(base_path, 'data', 'query', 'data_1.csv')

    print("Processing data...")
    main(ref_data_path, query_data_path, ref_label_path, ref_save_path, query_save_path)
    print("Processing complete!")
